package sharedPreferences;

public class Editor {
}
